NOVA Games survival fixes

Cloudflare ZIP: upload directly to your existing Cloudflare Pages project.
Render update: replace existing GitHub server.js with render-server.js (rename to server.js). Keep package.json and the rest of your repository.

Deadlands is the original open-world survival game with its co-op room panel. The separate wave arena is removed from the menu. Co-op now relays nearby walker hit events, but world changes, loot, inventory, saves and NPC AI are NOT yet authoritative shared-state multiplayer. Each player's local world can differ.

W moves toward the camera's forward view in Frontline online and Deadlands. Frontline campaign already had camera-forward movement. Basic generated gun audio added to Frontline; Deadlands already had Web Audio effects and audio-unlock improved. Sound may require clicking/tapping the page first.

These changes were syntax-checked but have not been live-tested on two devices.
